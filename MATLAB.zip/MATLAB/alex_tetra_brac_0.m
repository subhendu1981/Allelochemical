
%%%%%%%%%%%%%%%%% Tetraselmis, Alexandrium and Brachionus %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% Holling type III toxic effect %%%%%%%%%%%%%%%%%%%%%%%%

function v = alex_tetra_brac_0(t,y,zz)

global I_RPN I_RPT K_RPN K_RPT mu_PN mu_PT Q_min_PN Q_min_PT delta_PN delta_PT...
    I_PNZ I_PTZ K_PNZ K_PTZ alpha_PN alpha_PT delta_Z phi_PN phi_PT ... 
    a1 a2 a3 a4 theta_Z K_TZ theta_NP K_TNP dilution

ylag_PN = zz(:,1);
ylag_PT = zz(:,2);
ylag_Z = zz(:,3);

v = zeros(6,1);

R = y(1);
Q_PN = y(2);
PN = y(3);
Q_PT = y(4);
PT = y(5);
Z = y(6);

v(1) = -I_RPN*R*PN/(K_RPN+R+a1*PN+a2*PT) - I_RPT*R*PT/(K_RPT+R+a3*PN+a4*PT);
v(2) = I_RPN*R/(K_RPN+R+a1*PN+a2*PT) - mu_PN*(1-Q_min_PN/Q_PN)*Q_PN;
v(3) = mu_PN*(1-Q_min_PN/Q_PN)*PN - delta_PN*PN - phi_PN*I_PNZ*PN^2*Z/(K_PNZ^2+PN^2) - theta_NP*PT^2*PN/(K_TNP^2+dilution*PN^2+PT^2);
v(4) = I_RPT*R/(K_RPT+R+a3*PN+a4*PT) - mu_PT*(1-Q_min_PT/Q_PT)*Q_PT; 
v(5) = mu_PT*(1-Q_min_PT/Q_PT)*PT - delta_PT*PT - phi_PT*I_PTZ*PT^2*Z/(K_PTZ^2+PT^2);
v(6) = alpha_PN*phi_PN*I_PNZ*ylag_PN(3)^2*ylag_Z(6)/(K_PNZ^2+ylag_PN(3)^2)...
     + alpha_PT*phi_PT*I_PTZ*ylag_PT(5)^2*ylag_Z(6)/(K_PTZ^2+ylag_PT(5)^2)...
     - delta_Z*Z - theta_Z*PT^2*Z/(K_TZ^2+dilution*PN^2+PT^2);

% v(1) = -I_RPN*R*PN/(K_RPN+R+a1*PN+a2*PT) - I_RPT*R*PT/(K_RPT+R+a3*PN+a4*PT);
% v(2) = I_RPN*R/(K_RPN+R+a1*PN+a2*PT) - mu_PN*(1-Q_min_PN/Q_PN)*Q_PN;
% v(3) = mu_PN*(1-Q_min_PN/Q_PN)*PN - delta_PN*PN - phi_PN*I_PNZ*PN^2*Z/(K_PNZ^2+PN^2+PT^2) - theta_NP*PT^2*PN/(K_TNP^2+PN^2+PT^2);
% v(4) = I_RPT*R/(K_RPT+R+a3*PN+a4*PT) - mu_PT*(1-Q_min_PT/Q_PT)*Q_PT; 
% v(5) = mu_PT*(1-Q_min_PT/Q_PT)*PT - delta_PT*PT - phi_PT*I_PTZ*PT^2*Z/(K_PTZ^2+PN^2+PT^2);
% v(6) = alpha_PN*phi_PN*I_PNZ*ylag_PN(3)^2*ylag_Z(6)/(K_PNZ^2+ylag_PN(3)^2+ylag_PT(5)^2)...
%      + alpha_PT*phi_PT*I_PTZ*ylag_PT(5)^2*ylag_Z(6)/(K_PTZ^2+ylag_PN(3)^2+ylag_PT(5)^2)...
%      - delta_Z*Z - theta_Z*PT^2*Z/(K_TZ^2+PN^2+PT^2);

