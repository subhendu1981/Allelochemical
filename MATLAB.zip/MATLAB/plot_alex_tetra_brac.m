
% Programme for the Paper
% Moorthi et al. (2024)
% Allelochemicals determine competition and grazing control in Alexandrium catenella
% in the Journal Harmful Algae
% Programme by Subhendu Chakraborty
% Leibniz Centre for Tropical Marine Research, Bremen, Germany

close all
clear all
clc

global I_RPN I_RPT K_RPN K_RPT mu_PN mu_PT Q_min_PN Q_min_PT delta_PN delta_PT...
    I_PNZ I_PTZ K_PNZ K_PTZ alpha_PN alpha_PT delta_Z phi_PN phi_PT ... 
    a1 a2 a3 a4 theta_Z K_TZ theta_NP K_TNP dilution 



%%%% Calibrated Parameters %%%%

I_RPN = 3e-10; % mumol N/mum^3/d % max nutrient uptake rate by non-toxic algae
K_RPN = 2e-03; %  mumol N/ml % half saturation constant for nut uptake ny non-toxic algae
I_RPT = 2e-10; % (1e-10,1e-09) % mumol N/mum^3/d % max nutrient uptake rate by toxic algae
K_RPT = 2e-03; % (2e-04,2e-03) mumol N/ml % half saturation constant for nut uptake ny non-toxic algae
mu_PN = 0.8; % 1/d % max growth rat of non-toxic algae
Q_min_PN = 3.5e-11; % mumol N/mum^3 % min cell quota of non-toxic algae
mu_PT = 0.4; % (0.1,0.5) 1/d % max growth rate of toxic algae
Q_min_PT = 5e-11; % (2e-11,2e-10) mumol N/mum^3 % min cell quota of toxic algae
delta_PN = 0.2; % 1/d % natural mortality of non-toxic algae
delta_PT = 0.15; % 1/d % natural mortality of toxic algae

I_PNZ = 1.6e+06; % mum^3/ind/d % max ingestion rate on non-toxic algae
K_PNZ = 2.1e+07; % mum^3/ml % half sat constant non-toxic algae
alpha_PN = 1e-06; % ind/mum^3 % conversion efficiency of non-toxic algae into zooplankton

I_PTZ = 1.8e+06; % mum^3/ind/d % max ingestion rate on toxic algae
K_PTZ = 1e+07; % mum^3/ml % half sat constant non-toxic algae
alpha_PT = 1e-06; % ind/mum^3 % conversion efficiency of toxic algae into zooplankton

delta_Z = 0.05; % 1/d % natural mortality of zooplankton

a1 = 6e-08; % mumol/mum^3 % competition
a2 = 1e-08; % mumol/mum^3 % competition
a3 = 2e-07; % mumol/mum^3 % competition
a4 = 8e-08; % mumol/mum^3 % competition

theta_Z = 2.3; % 1/d % toxic effect on zooplankton
K_TZ = 1.1e+07; % mum^3/ml % half saturation constant of toxic effect

theta_NP = 0*1e-00; % allelopathic effect on competitor
K_TNP = 1e+06; % half saturation of allelopathic effect

del = 1.6; % d % time delay in conversion of prey into zooplankton



%%%% Fixed parameters %%%%

Vol_NP = 435.63; % 0.23*10^3; % volume of non-toxic algae
Vol_TP = 14137.17; % 1.2*10^3; % volume of toxic algae

phi_PN = 0.5; % preference for non-toxic algae by zooplankton
phi_PT = (1-phi_PN); % preference for toxic algae by zooplankton

dilution = 0.1; % dilution of toxic effect 



%%%% initial conditions %%%%

Nut = 0.883; % mumol/ml % initial nutrient concentration
Q_PN_0 = 1e-10; % mumol/mum^3 % initial Tetraselmis quota concentration (non-toxic)
Q_PT_0 = 1e-10; % mumol/mum^3 % inital Alexandrium quota concentration (toxic)

var = 0.5; % Vary parameters by 50%

tdatab = []; % assigning empty matrix
dataNP = [];
dataTP = [];
dataZ = [];
xdataNPb = [];
xdataTPb = [];
xdataZb = [];


%%%% Experimental data %%%%

tdatab = [0 2 4 6 9 13 16];
dataNP(1,:) = Vol_NP*[28000.00 17624.36 54241.56 272866.57 546562.52 42298.47 3495.84];
dataNP(2,:) = Vol_NP*[28000.00 16794.98 264489.81 184786.24 947983.25 379193.30 99226.14];
dataNP(3,:) = Vol_NP*[28000.00 11978.64 434927.75 306871.22 918125.51 5274.87 2161.90];

dataTP(1,:) = Vol_TP*[880 836.01672 921.3245486 464.4537333 125.7168 0 0];
dataTP(2,:) = Vol_TP*[880 934.2155093 1637.910309 492.8896762 328.43514 0 0];
dataTP(3,:) = Vol_TP*[880 995.258 1567.914142 587.6761524 268.71966 0 0];

tdata1b = [0 2 4 6 9 13 16];
dataZ(1,:) = [1.00 0.53 0.67 2.22 8.00 49.00 114.33];
dataZ(2,:) = [1.00 0.47 0.11 0.56 1.33 5.00 82.00];
dataZ(3,:) = [1.00 0.47 0.89 2.22 6.33 88.00 129.00];

for i = 1:length(tdatab(1,:))
    xdataNPb(i) = mean(dataNP(:,i));
    xdataTPb(i) = mean(dataTP(:,i));
end

for i = 1:length(tdata1b(1,:))
    xdataZb(i) = mean(dataZ(:,i));
end


%%%% Total time of run %%%%

time_span1 = 20; % days

t_div = 0.01;
ts = 0:t_div:time_span1;
opttime = odeset('RelTol', 1e-8);%,'NonNegative',[1]);

TT = 0:0.001:time_span1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Alexandrium_Tetraselmis_Bachionus %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

par = [I_RPN K_RPN I_RPT K_RPT mu_PN Q_min_PN mu_PT Q_min_PT delta_PN...
    delta_PT I_PNZ K_PNZ alpha_PN I_PTZ K_PTZ alpha_PT delta_Z a1 a2 a3 a4 theta_Z K_TZ del Q_PN_0 Q_PT_0];
l = length(par);
par_temp = par;

for i = 1:2*l+1 % total number of run by varying parameters +- 50%
    i

    par_temp = par;
    if i<=l
        par_temp(i) = par(i) + var*par(i); % 50% increase 
    elseif (l<i) && (i<=2*l)
        par_temp(i) = par(i-l) - var*par(i-l); % 50% decrease
    end

    I_RPN = par_temp(1);
    K_RPN = par_temp(2);
    I_RPT = par_temp(3);
    K_RPT = par_temp(4);
    mu_PN = par_temp(5);
    Q_min_PN = par_temp(6);
    mu_PT = par_temp(7);
    Q_min_PT = par_temp(8);
    delta_PN = par_temp(9);
    delta_PT = par_temp(10);
    I_PNZ = par_temp(11);
    K_PNZ = par_temp(12);
    alpha_PN = par_temp(13);
    I_PTZ = par_temp(14);
    K_PTZ = par_temp(15);
    alpha_PT = par_temp(16);
    delta_Z = par_temp(17);
    a1 = par_temp(18);
    a2 = par_temp(19);
    a3 = par_temp(20);
    a4 = par_temp(21);
    theta_Z = par_temp(22);
    K_TZ = par_temp(23);
    del = par_temp(24);
    Q_PN_0 = par_temp(25);
    Q_PT_0 = par_temp(26);

    z0(1) = Nut;
    z0(2) = Q_PN_0;
    z0(3) = xdataNPb(1);
    z0(4) = Q_PT_0;
    z0(5) = xdataTPb(1);
    z0(6) = xdataZb(1);

    sol = dde23('alex_tetra_brac_0',[del,del,del],z0,ts);

    TT_temp = sol.x;
    NP_temp = sol.y(3,:);
    TP_temp = sol.y(5,:);
    ZZ_temp = sol.y(6,:);

    NP(i,:) = interp1(TT_temp,NP_temp,TT);
    TP(i,:) = interp1(TT_temp,TP_temp,TT);
    ZZ(i,:) = interp1(TT_temp,ZZ_temp,TT);

    TT_temp = [];
    NP_temp = [];
    TP_temp = [];
    ZZ_temp = [];
    x = [];
    sol.x = [];
    sol.y = [];

end

for i = 1:length(TT) % Extracting minimum and maximum values for the shaded region
    NP_min(i) = min(NP(:,i));
    NP_max(i) = max(NP(:,i));
    TP_min(i) = min(TP(:,i));
    TP_max(i) = max(TP(:,i));
    ZZ_min(i) = min(ZZ(:,i));
    ZZ_max(i) = max(ZZ(:,i));
end




%%%%%%% Plot Model Simulation %%%%%%%

figure(1)
set(figure(1),'Position',[100 60 900 200]);

xlim1 = 20;


subplot(1,3,1)

y1 = NP_min;                      %#create first curve
y2 = NP_max;                   %#create second curve
X = [TT,fliplr(TT)];                %#create continuous x value array for plotting
Y = [y1,fliplr(y2)];              %#create y values for out and then back
fill(X,Y,[150 200 91]/255,'FaceAlpha',0.1, 'LineStyle','none');%, LineWidth = 0.1);%, EdgeColor = [0 0.5 0]);                  %#plot filled area
hold on;

plot(TT,NP(end,:),'Color',[150 200 91]/255,'LineWidth',2)
xlim([-0.01 xlim1])
ylim([-35000000,500000000])
xlabel('time (days)')
ylabel('{\it Tetraselmis sp.} (\mum^3 ml^{-1})')
hold on;
set(gca,'FontSize',12)


subplot(1,3,2)

y1 = TP_min;                      %#create first curve
y2 = TP_max;                   %#create second curve
X = [TT,fliplr(TT)];                %#create continuous x value array for plotting
Y = [y1,fliplr(y2)];              %#create y values for out and then back
fill(X,Y,[0.9 0.0780 0.1840],'FaceAlpha',0.1, 'LineStyle','none');%, LineWidth = 0.1);%, EdgeColor = [0 0.5 0]);                  %#plot filled area
hold on;

plot(TT,TP(end,:),'Color',[0.9 0.0780 0.1840],'LineWidth',2)
xlim([-0.01 xlim1])
ylim([-2500000,35000000])
xlabel('time (days)')
ylabel('{\it A. catenella} (\mum^3 ml^{-1})')
hold on;
set(gca,'FontSize',12)


subplot(1,3,3)

y1 = ZZ_min;                      %#create first curve
y2 = ZZ_max;                   %#create second curve
X = [TT,fliplr(TT)];                %#create continuous x value array for plotting
Y = [y1,fliplr(y2)];              %#create y values for out and then back
fill(X,Y,[0.3010 0.7450 0.9330],'FaceAlpha',0.1, 'LineStyle','none');%, LineWidth = 0.1);%, EdgeColor = [0 0.5 0]);                  %#plot filled area
hold on;

plot(TT,ZZ(end,:),'Color',[0.3010 0.7450 0.9330],'LineWidth',2)
xlim([-0.01 xlim1])
ylim([-35,400])
xlabel('time (days)')
ylabel('{\it B. plicatilis} (individuals ml^{-1})')
hold on;
set(gca,'FontSize',12)



%%%%%%% Plot Experimental Data %%%%%%%

subplot(1,3,1)
plot(0,xdataNPb(1),'o','Color',[150 200 91]/255,'MarkerSize',5);
hold on
for i = 1:length(dataNP(1,:))
    exp_sd1(i) = std(dataNP(:,i));
end
er = errorbar(tdatab,xdataNPb,exp_sd1,'o','Color',[150 200 91]/255,'MarkerSize',6);
hold on;


subplot(1,3,2)
plot(0,xdataTPb(1),'o','Color',[0.9 0.0780 0.1840],'MarkerSize',5);
hold on
for i = 1:length(dataTP(1,:))
    exp_sd2(i) = std(dataTP(:,i));
end
er = errorbar(tdatab,xdataTPb,exp_sd2,'o','Color',[0.9 0.0780 0.1840],'MarkerSize',6);
hold on;


subplot(1,3,3)
plot(0,xdataZb(1),'o','Color',[0.3010 0.7450 0.9330],'MarkerSize',5);
hold on
for i = 1:length(dataZ(1,:))
    exp_sd3(i) = std(dataZ(:,i));
end
er = errorbar(tdata1b,xdataZb,exp_sd3,'o','Color',[0.3010 0.7450 0.9330],'MarkerSize',6);
hold on;





